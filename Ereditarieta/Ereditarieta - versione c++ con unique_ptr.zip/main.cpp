#define _CRT_SECURE_NO_WARNINGS
#include <stdbool.h>
#include <stdlib.h>

#include "canvas.h"

#include <string>
#include <iostream>
#include <vector>
#include <memory>

/*
type_of_object parameter_1 parameter_2 ... parameter_n

rectangle 0 0 79 24 *
point 5 15 ?
circle 10 10 4 @
circle 70 10 4 @
line 40 15 40 20 |
*/
/*
void draw_file(FILE *f, canvas *c)
{
	char type[30];
	while (fscanf(f, "%29s", type) == 1) {
		if (strcmp(type, "point") == 0) {
			int x, y;
			char ch;
			fscanf(f, "%d%d %c", &x, &y, &ch);
			canvas_set(c, x, y, ch);
		}
		else if (strcmp(type, "line") == 0) {
			int x0, y0, x1, y1;
			char ch;
			fscanf(f, "%d%d%d%d %c", &x0, &y0, &x1, &y1, &ch);
			canvas_line(c, x0, y0, x1, y1, ch);
		}
		else if (strcmp(type, "rectangle") == 0) {
			int x0, y0, x1, y1;
			char ch;
			fscanf(f, "%d%d%d%d %c", &x0, &y0, &x1, &y1, &ch);
			canvas_rectangle(c, x0, y0, x1, y1, ch);
		}
		else if (strcmp(type, "circle") == 0) {
			int xm, ym, r;
			char ch;
			fscanf(f, "%d%d%d %c", &xm, &ym, &r, &ch);
			canvas_circle(c, xm, ym, r, ch);
		}
	}
}
*/
struct shape {
	std::string name_;
    int x_, y_;
	char c_;

	shape(int x, int y, char c, std::string name) 
		: name_(std::move(name)), x_(x), y_(y), c_(c)
	{}

	virtual ~shape() = default;
	void set_name(std::string name) {
		name_ = std::move(name);
	}
	virtual void draw(canvas& c) const = 0;
};

struct point : public shape {
	point(int x, int y, char c, std::string name = "point") 
		: shape(x, y, c, std::move(name)) {}

	void draw(canvas& c) const override {
		c.set(x_, y_, c_);
	}
};

struct line : public shape {
	int x1_, y1_;

	line(int x, int y, int x1, int y1, char c, std::string name = "line")
	: shape(x, y, c, std::move(name)), x1_(x1), y1_(y1) {}

	void draw(canvas& c) const override {
		c.line(x_, y_, x1_, y1_, c_);
	}
};

struct rectangle : public shape {
	int x1_, y1_;

	rectangle(int x, int y, int x1, int y1, char c, std::string name = "rectangle")
		: shape(x, y, c, std::move(name)), x1_(x1), y1_(y1) {}

	void draw(canvas& c) const override {
		c.rectangle(x_, y_, x1_, y1_, c_);
	}
};

struct circle : public shape {
	int r_;

	circle(int x, int y, int r, char c, std::string name = "circle")
		: shape(x, y, c, std::move(name)), r_(r) {}

	void draw(canvas& c) const override {
		c.circle(x_, y_, r_, c_);
	}
};

int main(void)
{
	canvas c(80, 25);

	std::vector<std::shared_ptr<shape>> arr;
	arr.emplace_back(std::make_shared<point>(5, 15, '?'));
	arr.emplace_back(std::make_shared<rectangle>(0, 0, 79, 24, '*'));
	arr.emplace_back(std::make_shared<circle>(10, 10, 4, '@'));
	arr.emplace_back(std::make_shared<circle>(70, 10, 4, '@'));
	arr.emplace_back(std::make_shared<line>(40, 15, 40, 20, '|'));
	
	for (const auto& s : arr) {
		s->draw(c);
	}

	c.out(std::cout);
}