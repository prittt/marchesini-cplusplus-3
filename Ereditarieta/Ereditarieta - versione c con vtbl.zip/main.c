#define _CRT_SECURE_NO_WARNINGS
#include <stdbool.h>
#include <stdlib.h>

#include "canvas.h"
#include "string.h"

/*
type_of_object parameter_1 parameter_2 ... parameter_n

rectangle 0 0 79 24 *
point 5 15 ?
circle 10 10 4 @
circle 70 10 4 @
line 40 15 40 20 |
*/
/*
void draw_file(FILE *f, canvas *c)
{
	char type[30];
	while (fscanf(f, "%29s", type) == 1) {
		if (strcmp(type, "point") == 0) {
			int x, y;
			char ch;
			fscanf(f, "%d%d %c", &x, &y, &ch);
			canvas_set(c, x, y, ch);
		}
		else if (strcmp(type, "line") == 0) {
			int x0, y0, x1, y1;
			char ch;
			fscanf(f, "%d%d%d%d %c", &x0, &y0, &x1, &y1, &ch);
			canvas_line(c, x0, y0, x1, y1, ch);
		}
		else if (strcmp(type, "rectangle") == 0) {
			int x0, y0, x1, y1;
			char ch;
			fscanf(f, "%d%d%d%d %c", &x0, &y0, &x1, &y1, &ch);
			canvas_rectangle(c, x0, y0, x1, y1, ch);
		}
		else if (strcmp(type, "circle") == 0) {
			int xm, ym, r;
			char ch;
			fscanf(f, "%d%d%d %c", &xm, &ym, &r, &ch);
			canvas_circle(c, xm, ym, r, ch);
		}
	}
}
*/
#define s(p) ((shape*)p)

typedef struct shape shape;

typedef	void* (*virtual_fn)();

typedef struct shape {
	char *name_;
    int x_, y_;
	char c_;
	virtual_fn *vtbl;
} shape;
void shape_draw(const shape *this, canvas *c) {
	printf("Error");
}
shape *shape_destroy(shape *this) {
	free(this->name_);
	return this;
}
virtual_fn shape_vtbl[] = {(virtual_fn)shape_draw, (virtual_fn)shape_destroy};
shape *shape_create(shape *this, int x, int y, char c, const char *name) {
	this->name_ = strdup(name);
	this->x_ = x;
	this->y_ = y;
	this->c_ = c;
	this->vtbl = shape_vtbl;
	return this;
}
shape *new_shape(int x, int y, char c, const char *name) {
    return shape_create(malloc(sizeof(shape)), x, y, c, name);
}
void delete_shape(shape *this) {
    free(this->vtbl[1](this));
}
void shape_set_name(shape *this, const char *name) {
	free(this->name_);
	this->name_ = strdup(name);
}

typedef struct point {
	shape base_;
} point;
void point_draw(const point *this, canvas *c) {
	canvas_set(c, this->base_.x_, this->base_.y_, this->base_.c_);
}
point *point_destroy(point *this) {
	shape_destroy(s(this));
	return this;
}
virtual_fn point_vtbl[] = {(virtual_fn)point_draw, (virtual_fn)point_destroy};
point *point_create(point *this, int x, int y, char c) {
	shape_create(s(this), x, y, c, "point");
	this->base_.vtbl = point_vtbl;
	return this;
}
point *new_point(int x, int y, char c) {
    return point_create(malloc(sizeof(point)), x, y, c);
}
void delete_point(point *this) {
    free(point_destroy(this));
}

typedef struct rectangle {
	shape base_;
	int x1_, y1_;
} rectangle;
void rectangle_draw(const rectangle *this, canvas *c) {
	canvas_rectangle(c, this->base_.x_, this->base_.y_, this->x1_, this->y1_, this->base_.c_);
}
rectangle *rectangle_destroy(rectangle *this) {
	shape_destroy(s(this));
	return this;
}
virtual_fn rectangle_vtbl[] = {(virtual_fn)rectangle_draw, (virtual_fn)rectangle_destroy};
rectangle *rectangle_create(rectangle *this, int x, int y, int x1, int y1, char c) {
	shape_create(s(this), x, y, c, "rectangle");
	this->base_.vtbl = rectangle_vtbl;
	this->x1_ = x1;
	this->y1_ = y1;
	return this;
}
rectangle *new_rectangle(int x, int y, int x1, int y1, char c) {
    return rectangle_create(malloc(sizeof(rectangle)), x, y, x1, y1, c);
}
void delete_rectangle(rectangle *this) {
    free(rectangle_destroy(this));
}

int main(void)
{
	canvas* c = new_canvas(80, 25);

	point *p1 = new_point(5, 15, '?');
	shape_set_name(s(p1), "ciccio");
	rectangle *r1 = new_rectangle(0, 0, 79, 24, '*');
	shape_set_name(s(r1), "prova");

	shape *arr[] = { s(p1), s(r1) };
	
	//point_draw(p1, c);
	//rectangle_draw(r1, c);

	for (size_t i = 0; i < 2; ++i) {
		arr[i]->vtbl[0](arr[i], c);
	}

	canvas_out(c, stdout);

	printf("%s\n", p1->base_.name_);
	printf("%s\n", r1->base_.name_);

	for (size_t i = 0; i < 2; ++i) {
		delete_shape(arr[i]);
	}
	delete_canvas(c);
}